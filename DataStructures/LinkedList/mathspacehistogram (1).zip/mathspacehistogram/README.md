# Steps to run this app.

# 1. download the zip file, do npm install

# 2. once you done the npm install you can able to run either npm start or yarn start.

# 3. once you run the commands you can able to see the Y-axis and X-axis Chart.

My Understanding about the Task:
What is the Task?

After I read the Instruction MD, I did understand there mentioned no third party libraries to be used for this task.

1-4 bars can be configured via code.
Initial starting values can be set for each bar.
The user should be able to drag the columns to a particular whole-number value.
A drag indicator should be visible when the bar moves indicating the bar value.
The Y-axis maximum can be set on initialisation and can be dynamically changed based on input value. Graph size be 300px × 300px, this should not change.
The Y-axis should not be able to be set lower than the histogram columns.
The value of the Y-axis should be allowed to be set to any number dynamically.
Bars should be drag top and bottom, bars height should not go below X-axis. While moving bars the resize value of bars should be shown.

My System Design for this Task:

General Thinking and my plan UI/UX:

1. First I have divided it into small pieces of React components
2. Choose canvas, make the 1-4 bars (not allowed to use the Third party library)
3. Can access the Bars and add the mouse drag and move top and bottom.
4. Draw X-axis (no ticks) and Y-axis numbers and ticks
5. Users can mouse cursor drag and move top and down and need to show the number
6. Y-axis maximum number text box number change, it will update the y-axis tick numbers as well.

Functional Requirements UI/UX:
Compulsory action plan to do:

1. App should be able to display the 1-4 bar charts and write the functionality to action to move and up and down.
2. Main focus functionality to write the numbers and ticks for the Y-axis.
3. main focus to write functionality for Y-axis maximum input to display.
4. We support a wide range of devices (mobiles, desktops and Tablets) - for this task I won't take action on this.
5. Draw x-axis as well but no need to show the ticks.
6. Write the function for User actions, after the user comes on to the histogram graph should action on the drag top and bottom.
7. Another important action: the Bar chart should not be below zero.

Tech stack I used:
React, React-dom, No third party libraries.
Just I used Functional components and react hooks mostly (useState, useEffect, useRef)

My Action Plans to Implement:

1. My action plan divide into small chunks and wrote the readable code
2. Efficient rendering - changing the Bar chart should be quick.

Component Architecture: functional components

1. App.tsx (my main parent component)
2. Histogram.tsx to call children components
3. Graph.tsx (Draw X-axis and Y-axis) Child component
4. Graph.css for styles (X-axis and Y-axis)
5. Bar.tsx another child component
6. Bar.css and BarTypes.tsx Files
7. Y-axisMax.tsx another component
8. App.css file

image.png
State Management:
As mentioned in task, No action required (I did not use any third Library redux and Mobx)

Any extra third party Library:
As mentioned in the task, No I did not install and used it.

Unit Testing E2E and component level:
As mentioned in task, No action required

Accessibility:
As mentioned in task, No action required

Extra Functionality:
As mentioned in task, No action required

Data Entities:
No data for this UI task, so no action required.

DataAPI:
No data for this UI task, so no action required.

Data Layer and Store
No data for this UI task, so no action required.

My End Output:
image.png

To be honest, I tried to finish but was not able to finish everything.
