import "./App.css";
import Histogram from "./components/histogram/Histogram";


function App() {
  return (
    <div className="App">
      <Histogram />
    </div>
  );
}

export default App;
