import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { BarConfigs, BarDataValue } from "../common/CommonTypes";

interface GraphNewProps {
  maxInputValue: number;
  intialBarConfigs: BarConfigs;
}

const Graph = ({ maxInputValue, intialBarConfigs }: GraphNewProps) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const { padding, gridStep, gridColor, dataValues, colors } = intialBarConfigs;

  const [barValues, setBarValues] = useState(dataValues);
  const [isDragging, setIsDragging] = useState<Boolean>(false);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [selectedRect, setSelectedRect] = useState<BarDataValue | null>(null);
  const [previousRect, setpreviousRect] = useState<BarDataValue | null>(null);

  useEffect(() => {
    //maxInputValue should not be less than bar max value
    //checking maxInputValue
    const barvalues: number[] = barValues.map((bar: BarDataValue) => bar.value);
    const maxBarValue = Math.max(...barvalues);
    if (maxBarValue < maxInputValue) {
      const ctcurrent = getCanvasContext().canvasCurrent;
      const ctx = getCanvasContext().ctx;
      ctx.clearRect(0, 0, ctcurrent.width, ctcurrent.height);
      //Drawing X axis and Y-axis  and Bars initially
      drawGridExpectLines();
      drawBars();
    }
  }, [maxInputValue]);

  const getCanvasContext = useCallback(() => {
    const ctcurrent = canvasRef.current as HTMLCanvasElement;
    const ctx = ctcurrent.getContext("2d") as CanvasRenderingContext2D;
    return { canvasCurrent: ctcurrent, ctx: ctx };
  }, [canvasRef]);
  const drawLine = (
    ctx: CanvasRenderingContext2D,
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    color: string
  ) => {
    //Drawing line 
    ctx.save();
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.stroke();
    ctx.restore();
  };

  const drawSmallRectangle = (
    ctx: CanvasRenderingContext2D,
    upperLeftCornerX: number,
    upperLeftCornerY: number
  ) => {
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = "#000";
    ctx.fillRect(
      upperLeftCornerX + 29,
      upperLeftCornerY - 6,
      14,
      14
    );
    ctx.fillStyle = "#fff";
    ctx.fillRect(upperLeftCornerX + 30, upperLeftCornerY - 5, 12, 12);
    ctx.closePath();
    ctx.restore();

    
  };

  const drawBar = (
    ctx: CanvasRenderingContext2D,
    upperLeftCornerX: number,
    upperLeftCornerY: number,
    width: number,
    height: number,
    color: string
  ) => {
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = "black";
    ctx.fillRect(
      upperLeftCornerX - 1,
      upperLeftCornerY - 1,
      width + 2,
      height + 2
    );
    ctx.fillStyle = color;
    ctx.fillRect(upperLeftCornerX, upperLeftCornerY, width, height);

    ctx.closePath();
    ctx.restore();
  };

  const getMultipleNumbersArray = (
    fistNumber: number,
    max: number,
    includeZero: boolean
  ) => {
    const list: number[] = [];
    for (let i = 0; fistNumber * i <= max; i++) {
      list.push(fistNumber * i);
    }
    if (!includeZero) {
      list.shift();
    }
    return list;
  };

  const  drawRectangle = (val: number, barIndex: number) => {
   
    const refCurrent = getCanvasContext().canvasCurrent;
    const ctx = getCanvasContext().ctx;
    const canvasActualHeight = refCurrent ? refCurrent.height - padding * 2 : 0;
    const canvasActualWidth = refCurrent ? refCurrent.width - padding * 2 : 0;

    let numberOfBars = barValues.length;
    let barSize = canvasActualWidth / numberOfBars - 32;
    let barHeight = Math.round((canvasActualHeight * val) / maxInputValue);

    const x = padding + barIndex * barSize;
    const barx = barIndex === 0 ? x : x + 50 * barIndex;
    const bary = refCurrent.height - barHeight - padding;

    drawBar(
      ctx,
      barx,
      bary,
      barSize,
      barHeight,
      colors[barIndex % colors.length]
    );

    drawSmallRectangle(
      ctx,
      barIndex === 0 ? x : x + 50 * barIndex,
      refCurrent.height - barHeight - padding
    );

    const newBarValues = [...barValues];
    const selectedBar = newBarValues[barIndex];
    if (val !== selectedBar.value) {
      selectedBar.value = val;
    }
    selectedBar.x = barx;
    selectedBar.y = bary;
    selectedBar.w = barSize;
    selectedBar.h = Math.round((canvasActualHeight * val) / maxInputValue);
    newBarValues[barIndex] = selectedBar;

    setBarValues([...newBarValues]);
  };
  const drawGridExpectLines = useCallback(() => {
    const refCurrent = getCanvasContext().canvasCurrent;
    const ctx = getCanvasContext().ctx;
    const canvasActualHeight = refCurrent ? refCurrent.height - padding * 2 : 0;
    const includeArray =  getMultipleNumbersArray(5, maxInputValue, true);

    for (let gridValue = 0; gridValue <= maxInputValue; gridValue += gridStep) {
      const gridY =
        canvasActualHeight * (1 - gridValue / maxInputValue) + padding;
      drawLine(
        ctx,
        gridValue === 0 ? 20 : 12,
        gridY,
        includeArray.includes(gridValue) ? refCurrent.width-10 : 20,
        gridY,
        gridColor
      );

      if (gridValue === 0) {
        drawLine(ctx, 20, padding, 20, gridY, gridColor);
      }
      // Writing grid markers
      ctx.save();
      ctx.fillStyle = gridColor;
      //this.ctx.textBaseline = "bottom";
      ctx.font = "bold 10px Arial";
      ctx.fillText(
         getMultipleNumbersArray(5, maxInputValue, false).includes(gridValue)
          ? gridValue.toString()
          : "",
        0,
        gridY + 2.5
      );
      ctx.restore();
    }
  }, [maxInputValue]);

  const drawBars = useCallback(() => {
    const values = barValues.map((bar: BarDataValue) => bar.value);

    for (let barIndex = 0; barIndex < values.length; barIndex++) {
       drawRectangle(values[barIndex], barIndex);
    }
  }, [maxInputValue, barValues]);

  const handleMousedown = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const mx = e.clientX - setOffset().offsetX;
    const my = e.clientY - setOffset().offsetY;
    barValues.forEach((rect: BarDataValue, index: number) => {
      if (
        (mx >= rect.x || mx >= rect.x + 29) &&
        (mx <= rect.x + rect.w || mx <= rect.x + 43) &&
        (my >= rect.y || my >= rect.y - 6) &&
        (my <= rect.y + rect.h || my <= rect.y + 12)
      ) {
        setSelectedIndex(index);
        setSelectedRect(rect);
      }
    });

    setIsDragging(true);
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    setSelectedIndex(null);
    setSelectedRect(null);
    setIsDragging(false);

    const refCurrent = getCanvasContext().canvasCurrent;
    const ctx = getCanvasContext().ctx;
    ctx.clearRect(0, 0, refCurrent.width, refCurrent.height);
    drawGridExpectLines();
    drawBars();
  };

  const handleChangeSelectedBar = (my: number) => {
    if (selectedRect && selectedIndex != null && isDragging) {
      setpreviousRect(barValues[selectedIndex]);
      let selectedbarIndexValue = barValues[selectedIndex].value;
      if (my >= selectedRect.y) {
        if (
          selectedbarIndexValue > 0 &&
          selectedbarIndexValue <= maxInputValue
        ) {
          selectedbarIndexValue -= 1;
        }
      } else if (my <= selectedRect.y + selectedRect.h) {
        if (
          selectedbarIndexValue >= 0 &&
          selectedbarIndexValue < maxInputValue
        ) {
          selectedbarIndexValue += 1;
        }
      }

      handleRedraw(selectedbarIndexValue);
    }
  };
  function handleRedraw(value: number) {
    if (isDragging && selectedIndex != null && selectedRect) {
      const refCurrent = getCanvasContext().canvasCurrent;
      const ctx = getCanvasContext().ctx;

      if (value <= maxInputValue) {
        if (previousRect && selectedRect.x === previousRect.x) {
          ctx.clearRect(previousRect.x + 29, previousRect.y - 6, 14, 14);
          ctx.clearRect(
            previousRect.x - 1,
            previousRect.y - 1,
            previousRect.w + 2,
            previousRect.h + 2
          );
        }

         drawRectangle(value, selectedIndex);

        const yaxis =
          (refCurrent.height - padding * 2) *
            (1 - selectedRect.value / maxInputValue) +
          padding;

        drawLine(ctx, 20, yaxis, refCurrent.width-15, yaxis, "#d3d3d3");

        ctx.save();
        ctx.fillStyle = gridColor;
        //ctx.textBaseline = "top";
        ctx.font = "10px Arial";
        ctx.fillText(value.toString(), refCurrent.width-11, yaxis - 25);
        ctx.restore();

      }
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const my = e.clientY - setOffset().offsetY;
    handleChangeSelectedBar(my);
  };

  const setOffset = useCallback(() => {
    const refCurrent = canvasRef.current as HTMLCanvasElement;
    let offsetX = 0;
    let offsetY = 0;
    if (refCurrent) {
      const client = refCurrent.getBoundingClientRect();
      offsetX = client.left;
      offsetY = client.top;
    }
    return { offsetX: offsetX, offsetY: offsetY };
  }, []);

  return (
    <div>
      <canvas
        id="myCanvas"
        ref={canvasRef}
        style={{ background: "#fff" }}
        width={500}
        height={500}
        onMouseDown={handleMousedown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      ></canvas>
    </div>
  );
};

export default Graph;
