 export interface BarConfigs {
    padding: number,
    gridStep:number,
    gridColor:string,
    dataValues:BarDataValue[],
    colors: string[]
  }
  
 export  interface BarDataValue {
  value: number,
  x:number,
  y: number,
  w:number,
  h:number
  }