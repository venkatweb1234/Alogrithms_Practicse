import React, { useState } from "react";

interface YaxisMaxInputProps {
  setYaxisMax: (val:number) => void
}

const YaxisMaxInput = ({ setYaxisMax}: YaxisMaxInputProps) => {
  const [YAxisMaxNumber, setYAxisMaxNumber] = useState(15);
  
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
   
    setYAxisMaxNumber(Number(event.target.value));

    setYaxisMax(Number(event.target.value));

  };
  return (
    <div>
      <label>Y-Axis Maximum: </label>
      <input type="text" value={YAxisMaxNumber} onChange={handleChange} />
    </div>
  );
};

export default YaxisMaxInput;
