import { useState } from "react";
import Graph from "../graph/Graph";
import YaxisMaxInput from "../yaxismax/YaxisMaxInput";

// Main Component for all child components
const Histogram = () => {
  const initialBarConfigs = {
    padding: 40,
    gridStep: 1,
    gridColor: "black",
    dataValues: [
      { value: 2, x: 0, y: 0, w: 0, h: 0 },
      { value: 4, x: 0, y: 0, w: 0, h: 0 },
      { value: 8, x: 0, y: 0, w: 0, h: 0 },
      { value: 0, x: 0, y: 0, w: 0, h: 0 },
    ],
    colors: ["#ff5733", "#33ffc7", "#9633ff", "#eb9743"],
  };

  const [yaxisMaxArrage, setYaxisMaxArrage] = useState(15);

  return (
    <div>
      <YaxisMaxInput setYaxisMax={setYaxisMaxArrage} />
      <Graph
        maxInputValue={yaxisMaxArrage}
        initialBarConfigs={initialBarConfigs}
      />
    </div>
  );
};

export default Histogram;
